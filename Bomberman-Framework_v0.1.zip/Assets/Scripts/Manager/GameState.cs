namespace Framework.Manager
{
    public enum GameState
    {
        Preperation,
        Running,
        GameOver
    }
}
