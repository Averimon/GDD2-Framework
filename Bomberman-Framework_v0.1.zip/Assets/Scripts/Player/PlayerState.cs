namespace Framework.Player
{
    public enum PlayerState
    {
        Alive,
        Dead
    }
}
