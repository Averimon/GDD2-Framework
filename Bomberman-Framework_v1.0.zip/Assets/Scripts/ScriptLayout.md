## ORDER OF VARIABLES
# Instance
1. Instance declaration

# Events, Fields and Properties
2. Events
3. Public variables
4. Properties without body
5. Editor variables (SeralizeField)
6. Protected variables
7. Private variables
8. Properties with body
